# **Technote**

### **1. Installation**
    git clone git@gitlab.info-ufr.univ-montp2.fr:e20140041615/Technote.git

### **2. Lancement**
Lancez le fichier index.html dans le navigateur

### **3. Modifications**
	git add *
    git commit -m "texte de la modification"
    git push origin master

### **4. NYI**
* Amélioration de la matrice de contraste

### **5. Annexe**
* https://coolors.co/